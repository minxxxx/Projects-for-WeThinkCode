#include <string.h>
int main(void)
{
	char *str = "hello";
	str[0] = 'a';
	return (0);
}
