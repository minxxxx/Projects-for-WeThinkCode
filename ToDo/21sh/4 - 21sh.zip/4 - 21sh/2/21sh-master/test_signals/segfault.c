#include <string.h>
int main(void)
{
	strlen(NULL);
	return (0);
}
