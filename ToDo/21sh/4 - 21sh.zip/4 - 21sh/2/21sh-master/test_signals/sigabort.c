#include <stdlib.h>
int main(void)
{
	free("salut");
	return (0);
}
