while true
do
	clear
	leaks $1
	sleep 3
done
